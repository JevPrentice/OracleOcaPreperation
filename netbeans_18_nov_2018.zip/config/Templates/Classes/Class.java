<#if package?? && package != "">
package ${package};

</#if>
/**
 *
 * @author ${user}
 * @since ${date}
 */
public class ${name} {

}
